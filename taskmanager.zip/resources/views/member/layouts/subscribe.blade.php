<section class="subscribe-section bg-color-3">
    <div class="pattern-layer" style="background-image: url({{ asset('') }}members/assets/images/shape/shape-2.png);"></div>
    <div class="auto-container">
        <div class="row clearfix">
            <div class="col-lg-12 col-md-6 col-sm-12 text-column text-center">
                <div class="text">
                    <span>{{ config('app.name') }}</span>
                    <h2>{{ date('Y') }} <sup>&copy;</sup> All right reserved</h2>
                </div>
            </div>
            
        </div>
    </div>
</section>